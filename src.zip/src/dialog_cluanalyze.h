#ifndef DIALOG_CLUANALYZE_H
#define DIALOG_CLUANALYZE_H

#include <QDialog>
#include <QtCharts/QtCharts>
#include <QtCharts/QChartView>
#include <QtCharts/QScatterSeries>
#include <QtMath>
#include <QLineSeries>
#include <QChart>
#include <QChartView>
#include <QBarCategoryAxis>
#include <QValueAxis>
#include <QBarSet>
#include <QBarSeries>
#include <QPen>
#include <QPainter>
#include <QVBoxLayout>
#include <QMessageBox>
#include <QTableWidget>
#include <QHash>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QPropertyAnimation>
#include <QParallelAnimationGroup>
#include <QTableWidget>
#include <QtDataVisualization/Q3DScatter>

namespace Ui {
class Dialog_CluAnalyze;
}

class Dialog_CluAnalyze : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog_CluAnalyze(QTableWidget *mom ,QWidget *parent = nullptr);
    ~Dialog_CluAnalyze();

private slots:
    void on_Button_KMeans_clicked();

    void on_Button_KMeans_2_clicked();

    void on_Button_KMeans_3_clicked();

    void on_Button_KMeans_4_clicked();

private:
    Ui::Dialog_CluAnalyze *ui;
    QTableWidget *tableWidget;
    Q3DScatter *scatter3D;
};

#endif // DIALOG_CLUANALYZE_H
