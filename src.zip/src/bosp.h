#ifndef BOSP_H
#define BOSP_H

#include <QDialog>
#include <QMainWindow>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QTableWidget>
#include <QHash>
#include <QtCharts>
#include <QtMath>
#include <QLineSeries>
#include <QChartView>
#include <QBarCategoryAxis>
#include <QValueAxis>
#include <QBarSet>
#include <QBarSeries>
#include <QPen>
#include <cmath>
#include <QMap>
#include <QPropertyAnimation>

QT_BEGIN_NAMESPACE
namespace Ui { class BOSP; }
QT_END_NAMESPACE

class BOSP : public QMainWindow
{
    Q_OBJECT

public:
    BOSP(QWidget *parent = nullptr);
    ~BOSP();

private slots:
    void on_actionchooseFile_triggered();

    void on_actioncomputeavarage_triggered();

    void on_actionHist_NDP_triggered();

    void on_actionScatter_Curve_Fit_triggered();

    void on_actionCovcorr_triggered();

    void on_actionHelp_triggered();

    void on_actionDRplot_triggered();

    void on_actionCluAnalyze_triggered();

private:
    Ui::BOSP *ui;
};
#endif // BOSP_H
