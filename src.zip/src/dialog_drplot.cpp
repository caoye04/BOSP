#include "dialog_drplot.h"
#include "ui_dialog_drplot.h"
#include "BospCompute.hpp"
#include "dialogfornewchartview.h"
#include <QtDataVisualization/Q3DScatter>
#include <QtDataVisualization/QScatterDataProxy>

Dialog_DRplot::Dialog_DRplot(QTableWidget *mom, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_DRplot),
    tableWidget(mom),
    scatter3D(nullptr)
{
    ui->setupUi(this);
    QList<QTableWidgetItem*> selectedItems = tableWidget->selectedItems();
    if (selectedItems.size() < 3)
    {
        QMessageBox::critical(this, "错误", "至少选择3列！");
        this->close(); // 关闭对话框
        return;
    }
    for (QTableWidgetItem *item : selectedItems)
    {
        int column = item->column();
        if (column == 0 || column == 1)
        {
            QMessageBox::critical(this, "错误", "请勿选择id列和diagnosis列！");
            this->close(); // 关闭对话框
            return;
        }
    }
}

Dialog_DRplot::~Dialog_DRplot()
{
    delete ui;
}

void Dialog_DRplot::on_pushButton2D_clicked()
{
    //二维绘图第一部分：从选中列中获得数据，并将其分别依据tableWidget的第二列数据(B&M)区别储存在两个二维向量中
    std::vector<std::vector<float>> selectedData;

    QList<QTableWidgetItem*> selectedItems = tableWidget->selectedItems();
    QVector<int> selectedColumns;
    for (QTableWidgetItem *item : selectedItems)
    {
        int column = item->column();
        if (!selectedColumns.contains(column))
        {
            selectedColumns.append(column);
        }
    }

    for(int row = 0; row < tableWidget->rowCount(); row++)
    {
        std::vector<float> rowData;
        for(auto col:selectedColumns)
        {
            QTableWidgetItem* item = tableWidget->item(row,col);
            float value = item->text().toFloat();
            rowData.push_back(value);
        }
        selectedData.push_back(rowData);
    }

    //二维绘图的第二部分：根据pca算法得到降维到二维的矩阵

    auto Pca2D = pca(selectedData, 2);

    //二维绘图的第三部分：进行图像绘制
    QChart *chart = new QChart();
    chart->setTitle("PCA of brease cancer dataset");
    QScatterSeries *seriesB1 = new QScatterSeries();
    QScatterSeries *seriesM0 = new QScatterSeries();

    seriesB1->setMarkerSize(8);
    seriesM0->setMarkerSize(8);
    seriesB1->setMarkerShape(QScatterSeries::MarkerShapeCircle);
    seriesM0->setMarkerShape(QScatterSeries::MarkerShapeCircle);
    seriesB1->setName("benign");
    seriesM0->setName("malignant");
    seriesB1->setColor(Qt::black);
    seriesM0->setColor(Qt::red);


    for (int i = 0; i < Pca2D.rows(); i++)
    {
        QTableWidgetItem* judgeBM = tableWidget -> item(i,1);
        if(judgeBM->text() == "B(1)")
        {
        seriesB1->append(Pca2D(i, 0), Pca2D(i, 1));
        }
        if(judgeBM->text() == "M(0)")
        {
        seriesM0->append(Pca2D(i, 0), Pca2D(i, 1));
        }
    }

    chart->addSeries(seriesB1);
    chart->addSeries(seriesM0);

    QValueAxis *axisX = new QValueAxis;
    QValueAxis *axisY = new QValueAxis;
    chart->addAxis(axisX, Qt::AlignBottom);
    chart->addAxis(axisY, Qt::AlignLeft);

    seriesB1->attachAxis(axisX);
    seriesB1->attachAxis(axisY);
    seriesM0->attachAxis(axisX);
    seriesM0->attachAxis(axisY);

    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    DialogForNewChartview *chartDialog = new DialogForNewChartview(chartView);
    chartDialog->show();
}


void Dialog_DRplot::on_pushButton3D_clicked()
{
    //三维绘图第一部分：从选中列中获得数据，并将其分别依据tableWidget的第二列数据(B&M)区别储存在两个二维向量中
    std::vector<std::vector<float>> selectedData;

    QList<QTableWidgetItem*> selectedItems = tableWidget->selectedItems();
    QVector<int> selectedColumns;
    for (QTableWidgetItem *item : selectedItems)
    {
        int column = item->column();
        if (!selectedColumns.contains(column))
        {
            selectedColumns.append(column);
        }
    }

    for(int row = 0; row < tableWidget->rowCount(); row++)
    {
        std::vector<float> rowData;
        for(auto col:selectedColumns)
        {
            QTableWidgetItem* item = tableWidget->item(row,col);
            float value = item->text().toFloat();
            rowData.push_back(value);
        }
        selectedData.push_back(rowData);
    }

    //三维绘图的第二部分：根据pca算法得到降维到三维的矩阵
    auto Pca3D = pca(selectedData, 3);

    //三维绘图的第三部分：绘制3D散点图
    if (!scatter3D) {
        scatter3D = new Q3DScatter();
        scatter3D->setFlags(scatter3D->flags() ^ Qt::FramelessWindowHint);
        QRect rect(250, 100, 1000, 600);
        scatter3D->setGeometry(rect);
    }

    QScatter3DSeries *seriesB1 = new QScatter3DSeries();
    QScatter3DSeries *seriesM0 = new QScatter3DSeries();

    seriesB1->setItemSize(0.08);
    seriesM0->setItemSize(0.08);
    seriesB1->setBaseColor(Qt::blue);
    seriesM0->setBaseColor(Qt::red);
    seriesB1->setName("B(1)");
    seriesM0->setName("M(0)");

    for (int i = 0; i < Pca3D.rows(); i++)
    {
        QTableWidgetItem* judgeBM = tableWidget -> item(i,1);
        if(judgeBM->text() == "B(1)")
        {
        seriesB1->dataProxy()->addItem(QVector3D(Pca3D(i, 0), Pca3D(i, 1), Pca3D(i, 2)));
        }
        if(judgeBM->text() == "M(0)")
        {
        seriesM0->dataProxy()->addItem(QVector3D(Pca3D(i, 0), Pca3D(i, 1), Pca3D(i, 2)));
        }
    }

    scatter3D->addSeries(seriesB1);
    scatter3D->addSeries(seriesM0);
    scatter3D->setAspectRatio(1.0);
    scatter3D->setHorizontalAspectRatio(1.0);

    scatter3D->show();
}

