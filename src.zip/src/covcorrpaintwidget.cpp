#include "covcorrpaintwidget.h"

#include <QPainter>

//构造函数，初始化对象CovCorrPaintWidget,并设置默认的颜色和判断绘制与否的判断数
CovCorrPaintWidget::CovCorrPaintWidget(QWidget *parent)
    : QWidget(parent)
{
    isCovMatrix_ = true;
}

//数据设置函数，这一步将外部的cov矩阵和corr矩阵传入
void CovCorrPaintWidget::setMatrices(const std::vector<std::vector<float>>& covMatrix, const std::vector<std::vector<float>>& corrMatrix)
{
    covMatrix_ = covMatrix;
    corrMatrix_ = corrMatrix;
    update();
}

//数据设置函数，这一步将外部的列数、各列的标签传入
void CovCorrPaintWidget::setColumnData(const QStringList& columnLabels, int columnCount)
{
    columnLabels_ = columnLabels;
    columnCount_ = columnCount;
    update();
}

//数据设置函数，这一步将外部的判断变量bool传入
void CovCorrPaintWidget::setJudgement(bool isCovMatrix)
{
    isCovMatrix_ = isCovMatrix;
    update();
}

//重写了QWidget的绘图事件处理函数。
//在小部件上绘制协方差矩阵或相关系数矩阵的可视化表示，包括矩阵方块、标签和颜色条。
void CovCorrPaintWidget::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    int n = covMatrix_.size(); // 矩阵的大小
    int cellSize = 0.8 * std::min(width(), height()) / n;
    int availableWidth = width() - cellSize * n;
    int availableHeight = height() - cellSize * n;

    QFont font = painter.font();
    font.setPointSize(10);
    painter.setFont(font);

    // 根据isCovMatrix_的值来绘制相应的矩阵
    if (isCovMatrix_)
    {
        for (int i = 0; i < n; ++i)
        {
            for (int j = 0; j < n; ++j)
            {
                QRect cellRect(availableWidth / 4 + i * cellSize, availableHeight / 2 + j * cellSize, cellSize, cellSize);
                QColor cellColor = mapValueToColor(covMatrix_[i][j]);
                painter.fillRect(cellRect, cellColor);
                QString text = QString::number(isCovMatrix_ ? covMatrix_[i][j] : corrMatrix_[i][j], 'f', 2);
                painter.drawText(cellRect, Qt::AlignCenter, text);
            }
        }
    }
    else
    {
        for (int i = 0; i < n; ++i)
        {
            for (int j = 0; j < n; ++j)
            {
                QRect cellRect(availableWidth / 4 + i * cellSize, availableHeight / 2 + j * cellSize, cellSize, cellSize);
                QColor cellColor = mapValueToColor(corrMatrix_[i][j]);
                painter.fillRect(cellRect, cellColor);
                QString text = QString::number(corrMatrix_[i][j], 'f', 2);
                painter.drawText(cellRect, Qt::AlignCenter, text);
            }
        }
    }

    //绘制标签
    for (int i = 0; i < n; ++i)
    {
        QRect labelRect(availableWidth / 4 + i * cellSize, height() - availableHeight / 2, cellSize, availableHeight / 2);
        painter.drawText(labelRect, Qt::AlignCenter, columnLabels_.at(i));
    }
    for (int i = 0; i < n; ++i)
    {
        QRect labelRect(0, availableHeight / 2 + i * cellSize, availableWidth / 4, cellSize);
        painter.save();
        painter.translate(labelRect.center().x() - 15 , labelRect.center().y());
        painter.rotate(-90);
        painter.drawText(-labelRect.height() / 2, 0, labelRect.height(), labelRect.width(), Qt::AlignCenter, columnLabels_.at(i));
        painter.restore();
    }

    //绘制颜色条
    QRect colorBarRect(width() - 100, availableHeight / 2, 20, 0.5*width());
    QLinearGradient gradient(colorBarRect.topLeft(), colorBarRect.bottomLeft());
    if (isCovMatrix_)
    {
        gradient.setColorAt(0.0, Qt::white);
        gradient.setColorAt(1.0, Qt::red);
    }
    else
    {
        gradient.setColorAt(0.0, Qt::blue);
        gradient.setColorAt(0.5, Qt::white);
        gradient.setColorAt(1.0, Qt::red);
    }
    painter.fillRect(colorBarRect, gradient);


    // 添加颜色条对应的标签    
    int labelX = width() - 75;
    int labelY = 0.122*width();

    QFont colorBarFont = painter.font();
    colorBarFont.setPointSize(10);
    painter.setFont(colorBarFont);

    if(isCovMatrix_)
    {
    QRect labelRect(labelX, availableHeight / 2 - 5, 80, 30);
    painter.drawText(labelRect, Qt::AlignTop, QString::number(minValue, 'f', 2));

    labelRect = QRect(labelX, availableHeight / 2 - 5 + labelY, 80, 30);
    painter.drawText(labelRect, Qt::AlignTop, QString::number((maxValue - minValue) / 4 + minValue , 'f', 2));

    labelRect = QRect(labelX, availableHeight / 2 - 5 + labelY * 2, 80, 30);
    painter.drawText(labelRect, Qt::AlignTop, QString::number((maxValue - minValue) / 4 * 2 + minValue , 'f', 2));

    labelRect = QRect(labelX, availableHeight / 2 - 5 + labelY * 3, 80, 30);
    painter.drawText(labelRect, Qt::AlignTop, QString::number((maxValue - minValue) / 4 * 3 + minValue , 'f', 2));

    labelRect = QRect(labelX, availableHeight / 2 - 5 + labelY * 4, 80, 30);
    painter.drawText(labelRect, Qt::AlignTop, QString::number(maxValue, 'f', 2));
    }
    else
    {
    QRect labelRect(labelX, availableHeight / 2 - 5, 80, 30);
    painter.drawText(labelRect, Qt::AlignTop, QString::number(-1, 'f', 2));

    labelRect = QRect(labelX, availableHeight / 2 - 5 + labelY, 80, 30);
    painter.drawText(labelRect, Qt::AlignTop, QString::number(-0.5, 'f', 2));

    labelRect = QRect(labelX, availableHeight / 2 - 5 + labelY * 2, 80, 30);
    painter.drawText(labelRect, Qt::AlignTop, QString::number(0, 'f', 2));

    labelRect = QRect(labelX, availableHeight / 2 - 5 + labelY * 3, 80, 30);
    painter.drawText(labelRect, Qt::AlignTop, QString::number(0.5, 'f', 2));

    labelRect = QRect(labelX, availableHeight / 2 - 5 + labelY * 4, 80, 30);
    painter.drawText(labelRect, Qt::AlignTop, QString::number(1, 'f', 2));
    }

    // 调用父类的paintEvent以确保正常绘制
    QWidget::paintEvent(event);
}

//用于计算矩阵中的最小值和最大值。
//这些值将用于计算映射矩阵中的数据到颜色。
void CovCorrPaintWidget::computeMinAndMaxValues(const std::vector<std::vector<float>>& matrix)
{
    minValue = matrix[0][0];
    maxValue = matrix[0][0];

    for (const auto& row : matrix)
    {
        for (float value : row)
        {
            if (value < minValue)
                minValue = value;
            if (value > maxValue)
                maxValue = value;
        }
    }
}

//根据给定的数值，将其映射到颜色。
//对于协方差矩阵和相关系数矩阵，会根据数值的范围选择不同的颜色映射方式。
QColor CovCorrPaintWidget::mapValueToColor(float value)
{
    if (isCovMatrix_)
    {
        computeMinAndMaxValues(covMatrix_);
        float t = (value - minValue) / (maxValue - minValue);
        return QColor(255, 255 * (1 - t), 255 * (1 - t));
    }
    else
    {
        if (value > 0)
        {
            return QColor(255, 255 * (1 - value), 255 * (1 - value));
        }
        if (value <= 0)
        {
            return QColor(255 * (1 + value),255 * (1 + value),255);
        }
    }
}
