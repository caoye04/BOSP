#include "dialog_avgvar.h"
#include "ui_dialog_avgvar.h"
#include "BospCompute.hpp"

// 这是直方图和正态分布曲线绘制功能部分

// 构造函数，接受一个表格指针和一个父窗口指针
// 作用是：将bosp.cpp里的表格传给dialog
Dialog_Avgvar::Dialog_Avgvar(QTableWidget *mom, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_Avgvar),
    tableWidget(mom)
{
    //第一部分：对table处理得到选中列的数据，data
    int column = tableWidget->currentColumn();
    int rowCount = tableWidget->rowCount();
    if(column < 2)
    {
        QMessageBox::warning(this, "错误", "请选择一个有效的列。");
        return;
    }
    QString columnHeader = tableWidget->horizontalHeaderItem(column)->text();
    std::vector<float> data;
    for (int row = 0; row < rowCount; ++row)
    {
        QTableWidgetItem *item = tableWidget->item(row, column);
        if (item)
        {
            float value = item->text().toFloat();
            data.push_back(value);
        }
    }

    //第二部分：计算和储存直方图相关特征，通过ferquencies储存直方图的下标大小，categories来设计书写方法
    QMap<int, int> histogram;
    int numberOfBins = 10;

    QStringList categories;
    QList<int> frequencies;

    float minVal = *std::min_element(data.begin(), data.end());
    float maxVal = *std::max_element(data.begin(), data.end());

    float binSize = (maxVal - minVal) / numberOfBins;

    for(int i = 0; i<10; i++)
    {
        QString category = "";
        float down_num = minVal + i*binSize;
        float up_num = minVal + (i+1)*binSize;
        category.append(QString::number(down_num,'f',3));
        category.append("~");
        category.append(QString::number(up_num,'f',3));
        categories.append(category);
    }
    for (float value : data)
    {
        int bin = static_cast<int>((value - minVal) / binSize);
        histogram[bin]++;
    }
    for(int i = 0; i<10 ; i++)
    {
        frequencies.append(histogram[i]);
    }

    //第三部分：创建柱状图，创建x轴y轴
    QChart *chart = new QChart;
    chart->setTitle("直方图和正态分布图");

    QBarSeries *series = new QBarSeries;

    QBarSet *set = new QBarSet("直方图");

    for (int i = 0; i < frequencies.size(); ++i)
    {
        *set << frequencies[i];
    }

    int maxFrequency = 0;
    for (int i = 0; i < frequencies.size(); ++i)
    {
        if (frequencies[i] > maxFrequency)
            maxFrequency = frequencies[i];
    }
    int chartMax = 1.2 * maxFrequency;

    series->append(set);

    chart->addSeries(series);

    QBarCategoryAxis *axisX = new QBarCategoryAxis;
    axisX->append(categories);

    QValueAxis *axisY = new QValueAxis;
    axisY->setTitleText(columnHeader);
    axisY->setRange(0, chartMax);

    chart->addAxis(axisX, Qt::AlignBottom);
    chart->addAxis(axisY, Qt::AlignLeft);
    chart->addSeries(series);
    series->attachAxis(axisX);
    series->attachAxis(axisY);

    series->setLabelsPosition(QAbstractBarSeries::LabelsInsideEnd);
    series->setLabelsVisible(true);

    //第四部分：将所创建的charts添加到窗口布局
    QChartView *chartView = new QChartView(chart);

    chartView->setRenderHint(QPainter::Antialiasing);
    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(chartView);
    setLayout(layout);

    //第五部分：正态曲线的绘制，计算均值方差，计算各个数据点对应的y值，绘制曲线
    auto avgVar = getAvgVar(data);

    float avg = std::get<0>(avgVar);
    float var = std::get<1>(avgVar);

    QSplineSeries *normalDistribution = new QSplineSeries();
    normalDistribution->setName("正态分布");

    for (int i = 0; i < categories.size(); ++i)
    {
        double stddev = sqrt(var);

        float down_num = minVal + i*binSize;
        double Ndown = (down_num - avg) / stddev;
        double cdfdown = 0.5 * (1 + std::erf(Ndown / sqrt(2)));

        float up_num = minVal + (i+1)*binSize;
        double Nup = (up_num - avg) / stddev;
        double cdfup = 0.5 * (1 + std::erf(Nup / sqrt(2)));

        double y = cdfup-cdfdown;
        qDebug()<<avg << var<< y;
        normalDistribution->append(i, y*rowCount);
    }

    chart->addSeries(normalDistribution);
    normalDistribution->attachAxis(axisX);
    normalDistribution->attachAxis(axisY);

    QPen pen;
    pen.setColor(Qt::red);
    pen.setWidth(2);
    normalDistribution->setPen(pen);

    //第六部分：为整个dialog和charts添加动画
    //第一个动画利用QPropertyAnimation实现，作用是将整个添加一个淡入的效果（更改透明度）
    //第二个动画是启用所有可能性的图表的动画
    setWindowOpacity(0);
    QParallelAnimationGroup *animationGroup = new QParallelAnimationGroup(this);
    QPropertyAnimation *chartOpacityAnimation = new QPropertyAnimation(this, "windowOpacity");
    chartOpacityAnimation->setStartValue(0.0);
    chartOpacityAnimation->setEndValue(1.0);
    chartOpacityAnimation->setDuration(500);
    animationGroup->addAnimation(chartOpacityAnimation);
    animationGroup->start();

    chart->setAnimationOptions(QChart::AllAnimations);

    ui->setupUi(this);
}

Dialog_Avgvar::~Dialog_Avgvar()
{
    delete ui;
}


void Dialog_Avgvar::on_checkBox_stateChanged(int arg1)
{
    // 获取复选框的选中状态
    bool isChecked = arg1 == Qt::Checked;

    // 获取图表视图
    QChartView *chartView = findChild<QChartView *>();
    if (chartView) {
        // 获取图表
        QChart *chart = chartView->chart();

        // 获取正态分布曲线序列
        QSplineSeries *normalDistributionSeries = nullptr;
        QList<QAbstractSeries *> seriesList = chart->series();
        for (QAbstractSeries *series : seriesList) {
            if (series->name() == "正态分布") {
                normalDistributionSeries = qobject_cast<QSplineSeries *>(series);
                break;
            }
        }

        // 根据复选框状态设置正态分布曲线序列的可见性
        if (normalDistributionSeries) {
            normalDistributionSeries->setVisible(!isChecked);
        }
        chart->setAnimationOptions(QChart::NoAnimation);
    }
}

