#ifndef DIALOG_SCACUR_H
#define DIALOG_SCACUR_H

#include <QtCharts/QChartView>
#include <QtCharts/QScatterSeries>
#include <QtCharts/QValueAxis>
#include <QtMath>
#include <QLineSeries>
#include <QChart>
#include <QBarCategoryAxis>
#include <QValueAxis>
#include <QBarSet>
#include <QBarSeries>
#include <QPen>
#include <QPainter>
#include <QVBoxLayout>
#include <QMessageBox>
#include <QTableWidget>
#include <QHash>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QPropertyAnimation>
#include <QParallelAnimationGroup>
#include <QTableWidgetItem>
#include <vector>
#include <QTimer>
#include <QPalette>

namespace Ui {
class dialog_scacur;
}

class dialog_scacur : public QDialog
{
    Q_OBJECT

public:
    explicit dialog_scacur(QTableWidget *mom , QWidget *parent = nullptr);
    ~dialog_scacur();

private slots:
    void on_pushButton_clicked();
    void mousePoint(const QPointF &point, bool);

private:
    Ui::dialog_scacur *ui;
    QTableWidget *tableWidget;
    QChartView *chartView;
    QValueAxis *xAxis;
    QValueAxis *yAxis;
    QScatterSeries *scatterSeries;
    QLabel *mouselabel;
};

#endif // DIALOG_SCACUR_H
