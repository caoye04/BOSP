#ifndef DIALOG_DRPLOT_H
#define DIALOG_DRPLOT_H

#include <QDialog>
#include <QtCharts/QtCharts>
#include <QtCharts/QChartView>
#include <QtCharts/QScatterSeries>
#include <QtMath>
#include <QLineSeries>
#include <QChart>
#include <QChartView>
#include <QBarCategoryAxis>
#include <QValueAxis>
#include <QBarSet>
#include <QBarSeries>
#include <QPen>
#include <QPainter>
#include <QVBoxLayout>
#include <QMessageBox>
#include <QTableWidget>
#include <QHash>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QPropertyAnimation>
#include <QParallelAnimationGroup>
#include <QTableWidget>
#include <QtDataVisualization/Q3DScatter>

namespace Ui {
class Dialog_DRplot;
}

class Dialog_DRplot : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog_DRplot(QTableWidget *mom ,QWidget *parent = nullptr);
    ~Dialog_DRplot();

private slots:
    void on_pushButton2D_clicked();
    void on_pushButton3D_clicked();

private:
    Ui::Dialog_DRplot *ui;
    QTableWidget *tableWidget;
    Q3DScatter *scatter3D;
};

#endif // DIALOG_DRPLOT_H
