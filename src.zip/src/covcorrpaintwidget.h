#ifndef COVCORRPAINTWIDGET_H
#define COVCORRPAINTWIDGET_H

#include <QWidget>
#include <vector>
#include <QStringList>

class CovCorrPaintWidget : public QWidget
{
    Q_OBJECT

public:
    CovCorrPaintWidget(QWidget *parent = nullptr);

    // 设置cov矩阵和corr矩阵的函数
    void setMatrices(const std::vector<std::vector<float>>& covMatrix, const std::vector<std::vector<float>>& corrMatrix);

    // 设置列标题和列数量的函数
    void setColumnData(const QStringList& columnLabels, int columnCount);

    // 设置judgement的函数
    void setJudgement(bool isCovMatrix);

    //分析矩阵的最大值和最小值
    void computeMinAndMaxValues(const std::vector<std::vector<float>>& matrix);

    //将各个值对应到颜色上
    QColor mapValueToColor(float value);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    std::vector<std::vector<float>> covMatrix_; // 存储cov矩阵的成员变量
    std::vector<std::vector<float>> corrMatrix_; // 存储corr矩阵的成员变量
    QStringList columnLabels_; // 存储列标题的成员变量
    int columnCount_; // 存储列数量的成员变量
    bool isCovMatrix_; // 存储judgement的成员变量
    float minValue;
    float maxValue;//分析最大值和最小值
};

#endif // COVCORRPAINTWIDGET_H
