#ifndef DIALOGFORNEWCHARTVIEW_H
#define DIALOGFORNEWCHARTVIEW_H

#include <QDialog>
#include <QChartView>
#include <QLabel>
#include <QTimer>

namespace Ui {
class DialogForNewChartview;
}

class DialogForNewChartview : public QDialog
{
    Q_OBJECT

public:
    explicit DialogForNewChartview(QChartView *chartView,QWidget *parent = nullptr);
    void connectSeriesHoverSignals();
    void showHoverLabel(const QPointF &point, bool);
    ~DialogForNewChartview();

private:
    Ui::DialogForNewChartview *ui;
    QChartView *aNew_chartView;
    QLabel *m_hoverLabel;
};

#endif // DIALOGFORNEWCHARTVIEW_H
