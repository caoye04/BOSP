#ifndef DIALOG_AVGVAR_H
#define DIALOG_AVGVAR_H

#include <QtCharts/QtCharts>
#include <QtMath>
#include <QLineSeries>
#include <QChart>
#include <QChartView>
#include <QBarCategoryAxis>
#include <QValueAxis>
#include <QBarSet>
#include <QBarSeries>
#include <QPen>
#include <QPainter>
#include <QVBoxLayout>
#include <QMessageBox>
#include <QTableWidget>
#include <QHash>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QPropertyAnimation>
#include <QParallelAnimationGroup>

namespace Ui {
class Dialog_Avgvar;
}

class Dialog_Avgvar : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog_Avgvar(QTableWidget *mom , QWidget *parent = nullptr);
    ~Dialog_Avgvar();

private slots:
    void on_checkBox_stateChanged(int arg1);

private:
    Ui::Dialog_Avgvar *ui;
    QTableWidget *tableWidget;
};

#endif // DIALOG_AVGVAR_H
