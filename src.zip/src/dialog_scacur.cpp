#include "dialog_scacur.h"
#include "ui_dialog_scacur.h"
#include "BospCompute.hpp"

// 这是散点图和曲线拟合绘制功能部分

// 构造函数，接受一个表格指针和一个父窗口指针（将bosp.cpp里的表格传给dialog）
// 在构造函数里实现了以下功能：
//      1.散点图的绘制        4%
//      2.横轴纵轴名称的给出   3%
//      3.重叠点数量的给出     2%
dialog_scacur::dialog_scacur(QTableWidget *mom , QWidget *parent ) :
    QDialog(parent),
    ui(new Ui::dialog_scacur),
    tableWidget(mom),
    chartView(new QChartView(this)),
    xAxis(new QValueAxis),
    yAxis(new QValueAxis),
    scatterSeries(new QScatterSeries)
{
    ui->setupUi(this);

    // 构造函数第一部分：获取表格并对选择的列数、列的正确选择与否进行判断

    QModelIndexList selectedIndexes = tableWidget->selectionModel()->selectedColumns();

    // 检查是否选择了两列
    if (selectedIndexes.size() != 2)
    {
        QMessageBox::warning(this, "错误", "请选择两列以绘制散点图!!!");
        QDialog::reject();
        return;
    }
    // 获取选中列的列号
    int col1 = selectedIndexes[0].column();
    int col2 = selectedIndexes[1].column();
    QString xLabel = tableWidget->horizontalHeaderItem(col1)->text();
    QString yLabel = tableWidget->horizontalHeaderItem(col2)->text();

    if (col1 == 0 || col1 == 1 || col2 == 1)
    {
        QMessageBox::warning(this, "错误", "请选择有效列来绘制散点图。");
        QDialog::reject();
        return;
    }
    if(col1 == col2)
    {
        QMessageBox::warning(this, "错误", "请选择两列不同的列来绘制散点图。");
        QDialog::reject();
        return;
    }

    // 构造函数第二部分：获取选择这两列的数据，并将它们以点的形式按x从小到大的顺寻存在dataPoints这个vector中
    QList<QTableWidgetItem*> selectedItems = tableWidget->selectedItems();
    QVector<QPointF> dataPoints;
    for (int i = 0; i < selectedItems.size(); i += 2)
    {
        double x = selectedItems[i]->text().toDouble();
        double y = selectedItems[i + 1]->text().toDouble();
        dataPoints.append(QPointF(x, y));
    }
    std::sort(dataPoints.begin(), dataPoints.end(), [](const QPointF &a, const QPointF &b){return a.x() < b.x();});

    // 构造函数第三部分：计算重叠点的数量，并将其展示在label2中
    int overlapCount = 0;
    for (int i = 0; i < dataPoints.size(); ++i)
    {
        for (int j = i + 1; j < dataPoints.size(); ++j)
        {
            if (dataPoints[i].x() == dataPoints[j].x() && dataPoints[i].y() == dataPoints[j].y())
            {
                overlapCount++;
            }
        }
    }
    if (overlapCount == 0)
    {
        ui->label_2->setText(QString("没有重叠点"));
    }
    else
    {
        ui->label_2->setText(QString("重叠点的个数为：%1个").arg(overlapCount));
    }

    // 构造函数第四部分：创建散点图，将点阵、x轴与y轴等元素添加到chart中
    QChart *chart = new QChart();
    chartView->setMinimumSize(1200, 600);
    chartView->setMaximumSize(1200, 600);
    chartView->setChart(chart);

    chart->setTitle("散点图与其曲线拟合");
    QScatterSeries *scatterSeries = new QScatterSeries();
    scatterSeries->setMarkerSize(10);
    scatterSeries->setName("散点图");

    foreach (const QPointF &point, dataPoints)
    {
        scatterSeries->append(point);
    }
    chart->addSeries(scatterSeries);

    chart->addAxis(xAxis, Qt::AlignBottom);
    chart->addAxis(yAxis, Qt::AlignLeft);
    scatterSeries->attachAxis(xAxis);
    scatterSeries->attachAxis(yAxis);
    xAxis->setTitleText(xLabel);
    yAxis->setTitleText(yLabel);

    // 构造函数第五部分：将各大元素合理排版
    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(chartView);
    QHBoxLayout *horizontalLayout = new QHBoxLayout;
    horizontalLayout->addWidget(ui->spinBox);
    horizontalLayout->addWidget(ui->pushButton);
    horizontalLayout->addWidget(ui->label);
    horizontalLayout->addWidget(ui->label_2);
    horizontalLayout->addWidget(ui->label_3);
    layout->addLayout(horizontalLayout);

    //扩充功能：鼠标悬停
    mouselabel = new QLabel(this);
    mouselabel->setFixedSize(120, 20);
    mouselabel->move(QCursor::pos());
    mouselabel->hide();
    connect(scatterSeries,&QScatterSeries::hovered,this,&dialog_scacur::mousePoint);

    // 构造函数第六部分：创建动画使得展示更加美观
    //第一个动画利用QPropertyAnimation实现，作用是将整个添加一个淡入的效果（更改透明度）
    //第二个动画是启用所有可能性的图表的动画
    setWindowOpacity(0);
    QParallelAnimationGroup *animationGroup = new QParallelAnimationGroup(this);
    QPropertyAnimation *chartOpacityAnimation = new QPropertyAnimation(this, "windowOpacity");
    chartOpacityAnimation->setStartValue(0.0);
    chartOpacityAnimation->setEndValue(1.0);
    chartOpacityAnimation->setDuration(500);
    animationGroup->addAnimation(chartOpacityAnimation);
    animationGroup->start();

    chart->setAnimationOptions(QChart::AllAnimations);
}

dialog_scacur::~dialog_scacur()
{
    delete ui;
}


//  这里是槽函数，即判断spinbox的数再进行曲线拟合
//  这一部分完成了以下功能：
//      1.曲线图的绘制                               6%
//      2.根据spinbox来进行曲线拟合的绘制              4%
//      3.根据spinbox来计算拟合曲线的p和r2，并进行展示   6%
void dialog_scacur::on_pushButton_clicked()
{
    // 槽函数第一部分：获取数据并处理数据，包括spinbox的数和数据点
    int degree = ui->spinBox->value();

    QList<QTableWidgetItem*> selectedItems = tableWidget->selectedItems();
    QVector<QPointF> dataPoints;

    for (int i = 0; i < selectedItems.size(); i += 2)
    {
        double x = selectedItems[i]->text().toDouble();
        double y = selectedItems[i + 1]->text().toDouble();
        dataPoints.append(QPointF(x, y));
    }

    std::sort(dataPoints.begin(), dataPoints.end(), [](const QPointF &a, const QPointF &b) {return a.x() < b.x();});

    std::vector<float> xData;
    std::vector<float> yData;
    foreach (const QPointF &point, dataPoints)
    {
        xData.push_back(static_cast<float>(point.x()));
        yData.push_back(static_cast<float>(point.y()));
    }

    // 槽函数第二部分：调用拟合函数，得到res，并将p值和r2展示再label中
    std::tuple<Eigen::VectorXf, float, float> res = fitLeastSquareAndPR(xData, yData, degree);

    ui->label->setText(QString("p = %1,    r² = %2").arg(std::get<1>(res)).arg(std::get<2>(res)));

    // 槽函数第三部分：绘制拟合曲线
    // 包含了以下几个步骤：
    // 1.创建QLineSeries；2.从小到大将拟合点添加到QLineSeries；3.获取图表并移出之前的拟合曲线；
    // 4.将新的拟合曲线加入图表并进行关联坐标轴；5.设置颜色与线宽
    QLineSeries *fitSeries = new QLineSeries();
    fitSeries->setName("拟合曲线");

    Eigen::VectorXf coefficients = std::get<0>(res);
    double xMin = dataPoints.first().x();
    double xMax = dataPoints.last().x();

    for (double x = xMin; x <= xMax; x += (xMax - xMin) / 100.0)
    {
        double y = 0.0;
        for (int i = 0; i <= degree; i++)
        {
            y += coefficients[i] * std::pow(x, i);
        }
        fitSeries->append(x, y);
    }

    QChart *chart = chartView->chart();


    QList<QAbstractSeries*> seriesList = chart->series();
    for (QAbstractSeries* series : seriesList)
    {
        if (series->name() == "拟合曲线")
        {
            chart->removeSeries(series);
            delete series;
            break;
        }
    }

    chart->addSeries(fitSeries);
    scatterSeries->attachAxis(xAxis);
    scatterSeries->attachAxis(yAxis);
    fitSeries->attachAxis(xAxis);
    fitSeries->attachAxis(yAxis);

    QPen pen;
    pen.setColor(Qt::red);
    pen.setWidth(2);
    fitSeries->setPen(pen);
}


void dialog_scacur::mousePoint(const QPointF &point, bool)
{
    mouselabel->setText(QString("坐标: (%1,%2)").arg(point.x()).arg(point.y()));
    ui->label_3->setText(QString("坐标: (%1,%2)").arg(point.x()).arg(point.y()));

    QPoint cursorPos = QCursor::pos();
    cursorPos.setX(cursorPos.x() - 200);
    cursorPos.setY(cursorPos.y() - 40);
    mouselabel->move(cursorPos);
    mouselabel->show();

    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, [=](){
        mouselabel->hide();
        timer->deleteLater();
    });
    timer->start(3000);
}
