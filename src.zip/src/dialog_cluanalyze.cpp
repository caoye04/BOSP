#include "dialog_cluanalyze.h"
#include "ui_dialog_cluanalyze.h"
#include "BospCompute.hpp"
#include "dialogfornewchartview.h"
#include <QtDataVisualization/Q3DScatter>
#include <QtDataVisualization/QScatterDataProxy>

Dialog_CluAnalyze::Dialog_CluAnalyze(QTableWidget *mom, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_CluAnalyze),
    tableWidget(mom),
    scatter3D(nullptr)
{
    ui->setupUi(this);
    QList<QTableWidgetItem*> selectedItems = tableWidget->selectedItems();
    if (selectedItems.size() < 3)
    {
        QMessageBox::critical(this, "错误", "至少选择3列！");
        this->close(); // 关闭对话框
        return;
    }
    for (QTableWidgetItem *item : selectedItems)
    {
        int column = item->column();
        if (column == 0 || column == 1)
        {
            QMessageBox::critical(this, "错误", "请勿选择id列和diagnosis列！");
            this->close(); // 关闭对话框
            return;
        }
    }
}

Dialog_CluAnalyze::~Dialog_CluAnalyze()
{
    delete ui;
}

//槽函数1，能根据选中的多列进行KMeans聚类分析，并将分析结果放置到最后一列中
void Dialog_CluAnalyze::on_Button_KMeans_clicked()
{
    //KMeans分析函数第一部分：获得数据并将其储存在一个二维向量中
    std::vector<std::vector<float>> selectedDataKMeans;

    QList<QTableWidgetItem*> selectedItems = tableWidget->selectedItems();
    QVector<int> selectedColumns;
    for (QTableWidgetItem *item : selectedItems)
    {
        int column = item->column();
        if (!selectedColumns.contains(column))
        {
            selectedColumns.append(column);
        }
    }
    for(int row = 0; row < tableWidget->rowCount(); row++)
    {
        std::vector<float> rowDataKMeans;

        for(auto col:selectedColumns)
        {
            QTableWidgetItem* item = tableWidget->item(row,col);
            float value = item->text().toFloat();
            rowDataKMeans.push_back(value);
        }
        selectedDataKMeans.push_back(rowDataKMeans);
    }

    //KMeans分析函数第二部分：对所选列数据进行KMean分析,并得到一个储存分类结果的向量
    std::vector<float> resultKMeans;
    int numKMean = ui->spinBox->value();
    auto res_KMeans = clusterKMeans(selectedDataKMeans,numKMean);
    for (auto &label : std::get<1>(res_KMeans))
    {
        resultKMeans.push_back(label);
    }

    //KMeans分析函数第三部分：将KMeans的分析结果
    int rowCount = tableWidget->rowCount();
    int columnCount = tableWidget->columnCount();

        //检测之前的K_Means并删除旧的K_Means
    int kMeansColumnIndex = -1;
    for (int col = 0; col < columnCount; col++)
    {
        QTableWidgetItem *headerItem = tableWidget->horizontalHeaderItem(col);
        if (headerItem && headerItem->text() == "K_Means")
        {
            kMeansColumnIndex = col;
            break;
        }
    }
    if (kMeansColumnIndex != -1)
    {
        tableWidget->removeColumn(kMeansColumnIndex);
        tableWidget->horizontalHeader()->hideSection(kMeansColumnIndex);
        columnCount = tableWidget->columnCount();
    }
        //将结果导入数据
    tableWidget->setColumnCount(columnCount + 1);
    tableWidget->setHorizontalHeaderItem(columnCount, new QTableWidgetItem("K_Means"));
    QTableWidgetItem *headerItem = tableWidget->horizontalHeaderItem(columnCount);
    headerItem->setText("K_Means");
    for (int row = 0; row < rowCount; row++)
    {
        QTableWidgetItem *item = new QTableWidgetItem(QString::number(resultKMeans[row]));
        tableWidget->setItem(row, columnCount, item);
    }
    QMessageBox::information(this, "提示", "基于选中列产生的 KMeans 聚类分析结果已放置到最后一列。");
}

//槽函数2，能根据K_Means分析的结果进行染色
void Dialog_CluAnalyze::on_Button_KMeans_2_clicked()
{
    // 获取 K_Means 列的索引，并进行鲁棒性判断
    int kMeansColumnIndex = -1;
    int columnCount = tableWidget->columnCount();
    for (int col = 0; col < columnCount; col++)
    {
        QTableWidgetItem *headerItem = tableWidget->horizontalHeaderItem(col);
        if (headerItem && headerItem->text() == "K_Means")
        {
            kMeansColumnIndex = col;
            break;
        }
    }
    if (kMeansColumnIndex == -1)
    {
        // 未找到 K_Means 列，或者列名不是 "K_Means"，显示错误消息
        QMessageBox::critical(this, "错误", "未找到 K_Means 列。");
        return;
    }

    // 根据 K_Means 列的值设置行的背景颜色
    for (int row = 0; row < tableWidget->rowCount(); row++)
    {
        QTableWidgetItem *item = tableWidget->item(row, kMeansColumnIndex);
        if (item)
        {
            int kMeansValue = item->text().toInt();
            // 根据 K_Means 值设置不同的颜色
            switch (kMeansValue)
            {
            case 0:
                for (int col = 0; col < columnCount; col++)
                {
                    tableWidget->item(row, col)->setBackground(QBrush(QColor(126,132,247))); // 浅蓝色
                }
                break;
            case 1:
                for (int col = 0; col < columnCount; col++)
                {
                    tableWidget->item(row, col)->setBackground(QBrush(QColor(240,155,89))); // 橙色
                }
                break;
            case 2:
                for (int col = 0; col < columnCount; col++)
                {
                    tableWidget->item(row, col)->setBackground(QBrush(QColor(117,250,141))); // 浅绿
                }
                break;
            case 3:
                for (int col = 0; col < columnCount; col++)
                {
                    tableWidget->item(row, col)->setBackground(QBrush(QColor(239,136,190))); // 粉色
                }
                break;
            case 4:
                for (int col = 0; col < columnCount; col++)
                {
                    tableWidget->item(row, col)->setBackground(QBrush(QColor(255,254,145))); // 浅黄色
                }
                break;
            }
        }
    }
}

//槽函数3，能根据K_Means分析的结果对选中列进行二维降维绘制
void Dialog_CluAnalyze::on_Button_KMeans_3_clicked()
{
    //二维绘制的第一部分：得到选中数据，将其储存二维向量中
    std::vector<std::vector<float>> selectedData;

    QList<QTableWidgetItem*> selectedItems = tableWidget->selectedItems();
    QVector<int> selectedColumns;
    for (QTableWidgetItem *item : selectedItems)
    {
        int column = item->column();
        if (!selectedColumns.contains(column))
        {
            selectedColumns.append(column);
        }
    }
    int rowCount = tableWidget->rowCount();
    for (int row = 0; row < rowCount; row++)
    {
        std::vector<float> rowData;
        for (auto col : selectedColumns)
        {
            QTableWidgetItem* item = tableWidget->item(row, col);
            float value = item->text().toFloat();
            rowData.push_back(value);
        }
            selectedData.push_back(rowData);
    }

    //二维绘制第二部分：将选中数据进行pca降维分析
    auto Pca2DKM = pca(selectedData,2);

    //二维绘制第三部分：开始绘制
        //设置chart、设置点集
    QChart *chart = new QChart();
    chart->setTitle("PCA of brease cancer dataset by K_Means Clusters");

    QScatterSeries *seriesK0 = new QScatterSeries();
    QScatterSeries *seriesK1 = new QScatterSeries();
    QScatterSeries *seriesK2 = new QScatterSeries();
    QScatterSeries *seriesK3 = new QScatterSeries();
    QScatterSeries *seriesK4 = new QScatterSeries();

        // 设置散点的样式，颜色，大小等等
    seriesK0->setMarkerSize(10);
    seriesK1->setMarkerSize(10);
    seriesK2->setMarkerSize(10);
    seriesK3->setMarkerSize(10);
    seriesK4->setMarkerSize(10);

    seriesK0->setMarkerShape(QScatterSeries::MarkerShapeCircle);
    seriesK1->setMarkerShape(QScatterSeries::MarkerShapeCircle);
    seriesK2->setMarkerShape(QScatterSeries::MarkerShapeCircle);
    seriesK3->setMarkerShape(QScatterSeries::MarkerShapeCircle);
    seriesK4->setMarkerShape(QScatterSeries::MarkerShapeCircle);

    seriesK0->setColor(QColor(126,132,247));//浅蓝色
    seriesK1->setColor(QColor(240,155,89));//橙色
    seriesK2->setColor(QColor(177,250,141));//浅绿
    seriesK3->setColor(QColor(239,136,190));//粉色
    seriesK4->setColor(QColor(255,254,145));//浅黄色

        //根据K_Means的数据往点内添加数据
    int kMeansColumnIndex = -1;
    for (int col = 0; col < tableWidget->columnCount(); col++)
    {
            QTableWidgetItem *headerItem = tableWidget->horizontalHeaderItem(col);
            if (headerItem && headerItem->text() == "K_Means")
            {
            kMeansColumnIndex = col;
            break;
            }
    }
    if (kMeansColumnIndex == -1)
    {
            QMessageBox::critical(this, "错误", "未找到 K_Means 列。");
            return;
    }
    for (int i = 0; i < selectedData.size(); i++)
    {
        QTableWidgetItem *item = tableWidget->item(i, kMeansColumnIndex);

        int kMeansValue = item->text().toInt();
        switch (kMeansValue)
        {
        case 0:
            seriesK0->append(Pca2DKM(i,0),Pca2DKM(i,1));
            break;
        case 1:
            seriesK1->append(Pca2DKM(i,0),Pca2DKM(i,1));
            break;
        case 2:
            seriesK2->append(Pca2DKM(i,0),Pca2DKM(i,1));
            break;
        case 3:
            seriesK3->append(Pca2DKM(i,0),Pca2DKM(i,1));
            break;
        case 4:
            seriesK4->append(Pca2DKM(i,0),Pca2DKM(i,1));
            break;
        default:
            break;
        }
    }
    //将点集加入chart中，并设置好坐标轴匹配

    chart->addSeries(seriesK0);
    chart->addSeries(seriesK1);
    chart->addSeries(seriesK2);
    chart->addSeries(seriesK3);
    chart->addSeries(seriesK4);

        // 找到所有点集中的最小和最大坐标值
    QPointF minPoint, maxPoint;
    minPoint = maxPoint = seriesK0->at(0);

    QScatterSeries *allSeries[] = { seriesK0, seriesK1, seriesK2, seriesK3, seriesK4 };

    for (QScatterSeries *series : allSeries) {
        for (int i = 0; i < series->count(); i++) {
            QPointF point = series->at(i);
            minPoint.setX(qMin(minPoint.x(), point.x()));
            minPoint.setY(qMin(minPoint.y(), point.y()));
            maxPoint.setX(qMax(maxPoint.x(), point.x()));
            maxPoint.setY(qMax(maxPoint.y(), point.y()));
        }
    }

        // 设置坐标轴
    QValueAxis *axisX = new QValueAxis;
    axisX->setRange(minPoint.x(), maxPoint.x());
    chart->addAxis(axisX, Qt::AlignBottom);
    QValueAxis *axisY = new QValueAxis;
    axisY->setRange(minPoint.y(), maxPoint.y());
    chart->addAxis(axisY, Qt::AlignLeft);

        // 将坐标轴附加到系列
    seriesK0->attachAxis(axisX);
    seriesK0->attachAxis(axisY);
    seriesK1->attachAxis(axisX);
    seriesK1->attachAxis(axisY);
    seriesK2->attachAxis(axisX);
    seriesK2->attachAxis(axisY);
    seriesK3->attachAxis(axisX);
    seriesK3->attachAxis(axisY);
    seriesK4->attachAxis(axisX);
    seriesK4->attachAxis(axisY);

        //创建一个新的图表对话框并进行展示
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    DialogForNewChartview *chartDialog = new DialogForNewChartview(chartView);
    chartDialog->show();
}

//槽函数4，能根据K_Means分析的结果对选中列进行三维降维绘制
void Dialog_CluAnalyze::on_Button_KMeans_4_clicked()
{
    //三维绘制的第一部分：得到选中数据，将其储存二维向量中
    std::vector<std::vector<float>> selectedData;

    QList<QTableWidgetItem*> selectedItems = tableWidget->selectedItems();
    QVector<int> selectedColumns;
    for (QTableWidgetItem *item : selectedItems)
    {
        int column = item->column();
        if (!selectedColumns.contains(column))
        {
            selectedColumns.append(column);
        }
    }
    int rowCount = tableWidget->rowCount();
    for (int row = 0; row < rowCount; row++)
    {
        std::vector<float> rowData;
        for (auto col : selectedColumns)
        {
            QTableWidgetItem* item = tableWidget->item(row, col);
            float value = item->text().toFloat();
            rowData.push_back(value);
        }
        selectedData.push_back(rowData);
    }

    //三维绘制第二部分：将选中数据进行pca降维分析
    auto Pca3DKM = pca(selectedData,3);

    //三维绘制的第三部分：开始绘图
        //新建一个三维绘制的弹窗
    if (!scatter3D)
    {
        scatter3D = new Q3DScatter();
        scatter3D->setFlags(scatter3D->flags() ^ Qt::FramelessWindowHint);
        QRect rect(250, 100, 1000, 600);
        scatter3D->setGeometry(rect);
    }
        //设置点集和它的属性
    QScatter3DSeries *seriesK0 = new QScatter3DSeries();
    QScatter3DSeries *seriesK1 = new QScatter3DSeries();
    QScatter3DSeries *seriesK2 = new QScatter3DSeries();
    QScatter3DSeries *seriesK3 = new QScatter3DSeries();
    QScatter3DSeries *seriesK4 = new QScatter3DSeries();

    seriesK0->setItemSize(0.08);
    seriesK1->setItemSize(0.08);
    seriesK2->setItemSize(0.08);
    seriesK3->setItemSize(0.08);
    seriesK4->setItemSize(0.08);

    seriesK0->setBaseColor(QColor(126,132,247));//浅蓝色
    seriesK1->setBaseColor(QColor(240,155,89));//橙色
    seriesK2->setBaseColor(QColor(177,250,141));//浅绿
    seriesK3->setBaseColor(QColor(239,136,190));//粉色
    seriesK4->setBaseColor(QColor(255,254,145));//浅黄色

        //根据KMeans的结果往各个点集里面添加数据
    int kMeansColumnIndex = -1;
    for (int col = 0; col < tableWidget->columnCount(); col++)
    {
        QTableWidgetItem *headerItem = tableWidget->horizontalHeaderItem(col);
        if (headerItem && headerItem->text() == "K_Means")
        {
            kMeansColumnIndex = col;
            break;
        }
    }
    if (kMeansColumnIndex == -1)
    {
        QMessageBox::critical(this, "错误", "未找到 K_Means 列。");
        return;
    }
    for (int i = 0; i < selectedData.size(); i++)
    {
        QTableWidgetItem *item = tableWidget->item(i, kMeansColumnIndex);

        int kMeansValue = item->text().toInt();
        switch (kMeansValue)
        {
        case 0:
            seriesK0->dataProxy()->addItem(QVector3D(Pca3DKM(i, 0), Pca3DKM(i, 1), Pca3DKM(i, 2)));
            break;
        case 1:
            seriesK1->dataProxy()->addItem(QVector3D(Pca3DKM(i, 0), Pca3DKM(i, 1), Pca3DKM(i, 2)));
            break;
        case 2:
            seriesK2->dataProxy()->addItem(QVector3D(Pca3DKM(i, 0), Pca3DKM(i, 1), Pca3DKM(i, 2)));
            break;
        case 3:
            seriesK3->dataProxy()->addItem(QVector3D(Pca3DKM(i, 0), Pca3DKM(i, 1), Pca3DKM(i, 2)));
            break;
        case 4:
            seriesK4->dataProxy()->addItem(QVector3D(Pca3DKM(i, 0), Pca3DKM(i, 1), Pca3DKM(i, 2)));
            break;
        default:
            break;
        }
    }
        //将点集加入图中并展示
    scatter3D->addSeries(seriesK0);
    scatter3D->addSeries(seriesK1);
    scatter3D->addSeries(seriesK2);
    scatter3D->addSeries(seriesK3);
    scatter3D->addSeries(seriesK4);
    scatter3D->setAspectRatio(1.0);
    scatter3D->setHorizontalAspectRatio(1.0);

    scatter3D->show();

}

