#ifndef BOSPCOMPUTER
#define BOSPCOMPUTER
#include <iostream>
#include <vector>
#include "Eigen/Dense"

std::tuple<float, float> getAvgVar(const std::vector<float> &inX);

Eigen::MatrixXf pca(const std::vector<std::vector<float>> &in, const int k);

std::tuple<Eigen::VectorXf, float, float>
fitLeastSquareAndPR(const std::vector<float> &inX, const std::vector<float> &inY, const int inDegree);

std::tuple<Eigen::MatrixXf, std::vector<int>>
clusterKMeans(const std::vector<std::vector<float>> &in, const int k, const int maxIter);

std::tuple<Eigen::MatrixXf, std::vector<int>>
clusterKMeans(const std::vector<std::vector<float>> &in, const int k);

Eigen::MatrixXf getCovariance(std::vector<std::vector<float>> &inMat);

Eigen::MatrixXf getPearsonCorr(const Eigen::MatrixXf &cov, const std::vector<float> &vars);
#endif // BOSPCOMPUTER
