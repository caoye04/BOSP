#include "bosp.h"
#include "ui_bosp.h"
#include "BospCompute.hpp"
#include "dialog_avgvar.h"
#include "dialog_scacur.h"
#include "dialog_covcorr.h"
#include "dialog_drplot.h"
#include "dialog_cluanalyze.h"
#include "dialog_help.h"

BOSP::BOSP(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::BOSP)
{
    ui->setupUi(this);
}

BOSP::~BOSP()
{
    delete ui;
}


//这是ui界面中的ChooseFile的槽函数，它的功能是点击tool中的chooseFile按钮即能导入需要分析的表格
//实现了功能点：一/1、2
//完成百分比：6%
void BOSP::on_actionchooseFile_triggered()
{
    //弹出让用户选择.csv的对话框
    QString filePath = QFileDialog::getOpenFileName(this, "选择需要分析CSV文件", "", "CSV 文件 (*.csv)");

    //检测1：检测是否选择了文件
    if (filePath.isEmpty())
    {
        return;
    }

    //打开文件
    //检测2：检测选择的文件是否合法
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QMessageBox::warning(this,"错误", "无法打开文件：" + file.errorString());
        return;
    }

    //创建一个TextStream文本流来读取文件内容
    QTextStream in(&file);

    //先读取第一行，包含了各种标题
    //通过第一行的长度来决定表格的列数量
    QString header = in.readLine();
    QStringList headerFields = header.split(",");
    int colCount = headerFields.size();
    ui->tableWidget->setColumnCount(colCount);

    //逐行读取数据并插入每一行数据
    ui->tableWidget->setHorizontalHeaderLabels(headerFields);
    int row = 0;
    while (!in.atEnd())
    {
        QString line = in.readLine();
        QStringList fields = line.split(",");
        ui->tableWidget->insertRow(row);

        for (int col = 0; col < fields.size(); ++col)
        {
            QTableWidgetItem *item = new QTableWidgetItem(fields[col]);
            ui->tableWidget->setItem(row, col, item);
        }
        row++;
    }

    //通过哈希表将字母类型的数据处理为数字
    QHash<QString, int> discreteValueMap;
    int currentValue = 0;
    for (int row_Hash = 0; row_Hash < row; row_Hash++)
    {
        QTableWidgetItem* item = ui->tableWidget->item(row_Hash, 1);
        if (item)
        {
            QString text = item->text();
            if (!discreteValueMap.contains(text))
            {
                discreteValueMap[text] = currentValue;
                currentValue++;
            }
            item->setText(text+"("+QString::number(discreteValueMap[text])+")");
        }
    }

    //关闭文件
    file.close();
}


//这是ui界面中的Avg+Var的槽函数，它的功能是点击tool中的Avg+Var按钮即能分析选中这一列的均值与方差
//实现了功能点：一/3
//完成百分比：4%
void BOSP::on_actioncomputeavarage_triggered()
{
    //得到列数
    int column = ui->tableWidget->currentColumn();

    //监测点：判断选择的列是否合适
    if(column < 2)
    {
        QMessageBox::warning(this, "错误", "请选择一个有效的列。");
        return;
    }

    // 提取用户选择的列数据
    std::vector<float> data;
    int rowCount = ui->tableWidget->rowCount();
    for (int row = 0; row < rowCount; row++)
    {
        QTableWidgetItem *item = ui->tableWidget->item(row, column);
        if (item)
        {
            bool ok;
            float value = item->text().toDouble(&ok);
            if (ok)
            {
                data.push_back(value);
            }
        }
    }

    // 计算均值与方差，并在MessageBox里面展示
    auto avgVar = getAvgVar(data);
    QString resultText = QString("本列的均值与方差 \n均值： %1  方差： %2      ").arg(std::get<0>(avgVar)).arg(std::get<1>(avgVar));
    QMessageBox::information(this, "计算结果", resultText);
}


//这是ui界面中的Hist+NDP的槽函数，它的功能是点击tool中的Hist+NDP按钮即能生成这一列的直方图和正态分布图
//实现了功能点：一/4、5
//完成百分比：10%
//具体的代码实现在"dialog_avgvar.cpp"里阐述
void BOSP::on_actionHist_NDP_triggered()
{
    Dialog_Avgvar* new_dialog = new Dialog_Avgvar(ui->tableWidget,this);
    new_dialog->show();
}

//这是ui界面中的Sca+cur的槽函数，它的功能是点击tool中的Sca+cur按钮即能生成选中两列的散点图和拟合曲线
//实现了功能点：二
//完成百分比：25%
//具体的代码实现在"dialog_scacur.cpp"里阐述
void BOSP::on_actionScatter_Curve_Fit_triggered()
{
    dialog_scacur* new_dialog = new dialog_scacur(ui->tableWidget,this);
    new_dialog->show();
}

//这是ui界面中的Cov+Corr的槽函数，它的功能是点击tool中的Cov+Corr按钮即能生成选中多列的协方差矩阵和相关系数矩阵
//实现了功能点：三
//完成百分比：20%
//具体的代码实现在"dialog_covcorr.cpp"里阐述
void BOSP::on_actionCovcorr_triggered()
{
    dialog_covcorr* new_dialog = new dialog_covcorr(ui->tableWidget,this);
    new_dialog->show();
}

//这里是ui界面的DRplot的槽函数，它的功能点是点击tool中的DRplot按钮即能选择生成选中多列数据的二维降维散点图和三维降维散点图
//实现了功能点：四
//完成百分比：15%
//具体的代码实现在"dialog_drplot.cpp"里面阐述
void BOSP::on_actionDRplot_triggered()
{
    Dialog_DRplot* new_dialog = new Dialog_DRplot(ui->tableWidget,this);
    new_dialog->show();
}

//这里是ui界面的CluAnalyze的槽函数，它的功能点是点击tool中的CluAnalyze按钮即能根据所选的列进行聚类分析
//实现了功能点：五
//完成百分比：20%
//具体的代码实现在"dialog_drplot.cpp"里面阐述
void BOSP::on_actionCluAnalyze_triggered()
{
    Dialog_CluAnalyze* new_dialog = new Dialog_CluAnalyze(ui->tableWidget,this);
    new_dialog->move(0, 70);
    new_dialog->show();
}

//这是ui界面的Help的槽函数，它的功能是点击tool中的Help按钮即能跳出Help对话框
//这里不是需求点的内容，但是他能帮助用户更好地使用我们的BOSP系统
void BOSP::on_actionHelp_triggered()
{
    Dialog_help* new_dialog = new Dialog_help;
    new_dialog->show();
}


