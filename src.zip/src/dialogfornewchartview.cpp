#include "dialogfornewchartview.h"
#include "ui_dialogfornewchartview.h"
#include <QVBoxLayout>
#include <QtWidgets>
#include <QScatterSeries>

DialogForNewChartview::DialogForNewChartview(QChartView *chartView,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogForNewChartview),
    aNew_chartView(chartView),
    m_hoverLabel(nullptr)
{
    ui->setupUi(this);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(aNew_chartView);
    setLayout(layout);

    // 创建用于悬停信息的QLabel并进行初始化
    m_hoverLabel = new QLabel(this);
    m_hoverLabel->setFixedSize(150, 20);
    m_hoverLabel->hide();

    // 连接QScatterSeries的hovered信号到槽函数
    connectSeriesHoverSignals();
}

DialogForNewChartview::~DialogForNewChartview()
{
    delete ui;
}

void DialogForNewChartview::connectSeriesHoverSignals()
{
    QList<QAbstractSeries*> seriesList = aNew_chartView->chart()->series();
    for (QAbstractSeries *series : seriesList)
    {
        if (QScatterSeries *scatterSeries = qobject_cast<QScatterSeries*>(series))
        {
            connect(scatterSeries, &QScatterSeries::hovered, this, &DialogForNewChartview::showHoverLabel);
        }
    }
}

void DialogForNewChartview::showHoverLabel(const QPointF &point, bool)
{
    m_hoverLabel->setText(QString("坐标: (%1,%2)").arg(point.x()).arg(point.y()));

    QPoint cursorPos = QCursor::pos();
    cursorPos.setX(cursorPos.x() - 200);
    cursorPos.setY(cursorPos.y() - 40);
    m_hoverLabel->move(cursorPos);
    m_hoverLabel->show();

    // 创建一个定时器，用于在3秒后隐藏悬停信息
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, [=]() {
        m_hoverLabel->hide();
        timer->deleteLater();
    });
    timer->start(3000);
}
