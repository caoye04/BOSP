#include "dialog_covcorr.h"
#include "ui_dialog_covcorr.h"
#include "BospCompute.hpp"

// 这是协方差矩阵和绘制功能部分

// 构造函数，接受一个表格指针和一个父窗口指针
// 作用是：将bosp.cpp里的表格传给dialog
dialog_covcorr::dialog_covcorr(QTableWidget *mom, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dialog_covcorr),
    tableWidget(mom)
{
    ui->setupUi(this);

    // 构造函数第一部分：获得选中列的数据并将其储存在一个二维向量里，将各列的标题存在一个Qstringlist里面,并进行一定的鲁棒性检测
    QList<QTableWidgetItem*> selectedItems = tableWidget->selectedItems();
    QVector<int> selectedColumns;
    for (QTableWidgetItem *item : selectedItems)
    {
        int column = item->column();
        if (column < 2)
        {
            QMessageBox::critical(this, "错误", "请勿选择id列和diagnosis列！");
            this->close(); // 关闭对话框
            return;
        }
        if (!selectedColumns.contains(column))
        {
            selectedColumns.append(column);
        }
    }
    std::vector<std::vector<float>> selectedData;
    for (int column : selectedColumns)
    {
        std::vector<float> columnData;
        for (int row = 1; row < tableWidget->rowCount(); ++row)
        {
            QTableWidgetItem *item = tableWidget->item(row, column);
            if (item)
            {
                float cellData = item->text().toFloat();
                columnData.push_back(cellData);
            }
        }
        selectedData.push_back(columnData);
    }
    QStringList columnLabels;
    for (int column : selectedColumns)
    {
        QTableWidgetItem *headerItem = tableWidget->horizontalHeaderItem(column);
        if (headerItem)
        {
            QString labelText = headerItem->text();
            columnLabels.append(labelText);
        }
    }

    // 构造函数第二部分：计算得到协方差矩阵和相关系数矩阵
    auto cov = getCovariance(selectedData);
    std::vector<float> vars;
    for (auto vec : selectedData)
    {
        auto avgVar = getAvgVar(vec);
        vars.push_back(std::get<1>(avgVar));
    }
    auto corr = getPearsonCorr(cov, vars);
    Eigen::MatrixXf cov_float = cov.cast<float>();
    Eigen::MatrixXf corr_float = corr.cast<float>();
    std::vector<std::vector<float>> covVector;
    for (int i = 0; i < cov_float.rows(); ++i)
    {
        std::vector<float> row;
        for (int j = 0; j < cov_float.cols(); ++j)
        {
            row.push_back(cov_float(i, j));
        }
        covVector.push_back(row);
    }
    std::vector<std::vector<float>> corrVector;
    for (int i = 0; i < corr_float.rows(); ++i)
    {
        std::vector<float> row;
        for (int j = 0; j < corr_float.cols(); ++j)
        {
            row.push_back(corr_float(i, j));
        }
        corrVector.push_back(row);
    }

    // 构造函数第三部分：绘制图像
    covCorrPaintWidget = new CovCorrPaintWidget(this);
    covCorrPaintWidget->setGeometry(100, 50, 800, 500);
    covCorrPaintWidget->setMatrices(covVector, corrVector);
    covCorrPaintWidget->setColumnData(columnLabels, selectedColumns.size());
    covCorrPaintWidget->setJudgement(judgement);

    QVBoxLayout *layout = new QVBoxLayout();
    layout->addWidget(covCorrPaintWidget);
}

dialog_covcorr::~dialog_covcorr()
{
    delete ui;
}

void dialog_covcorr::on_radioButton_clicked()
{
    judgement = true;
    covCorrPaintWidget->setJudgement(judgement);
}

void dialog_covcorr::on_radioButton_2_clicked()
{
    judgement = false;
    covCorrPaintWidget->setJudgement(judgement);
}

