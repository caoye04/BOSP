#ifndef DIALOG_COVCORR_H
#define DIALOG_COVCORR_H

#include "covcorrpaintwidget.h"
#include <QtCharts/QtCharts>
#include <QtMath>
#include <QLineSeries>
#include <QChart>
#include <QChartView>
#include <QBarCategoryAxis>
#include <QValueAxis>
#include <QBarSet>
#include <QBarSeries>
#include <QPen>
#include <QPainter>
#include <QVBoxLayout>
#include <QMessageBox>
#include <QTableWidget>
#include <QHash>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QPropertyAnimation>
#include <QParallelAnimationGroup>
#include <QDialog>
#include "Eigen/Dense"

namespace Ui {
class dialog_covcorr;
}

class dialog_covcorr : public QDialog
{
    Q_OBJECT

public:
    explicit dialog_covcorr(QTableWidget *mom ,QWidget *parent = nullptr);
    ~dialog_covcorr();

private slots:
    void on_radioButton_clicked();

    void on_radioButton_2_clicked();

private:
    Ui::dialog_covcorr *ui;
    QTableWidget *tableWidget;
    bool  judgement;
    CovCorrPaintWidget* covCorrPaintWidget;
};

#endif // DIALOG_COVCORR_H
